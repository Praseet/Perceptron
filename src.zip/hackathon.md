Mastercard Innovation Challenge @ GFF 2026 - AI Defense Lab for Payment Security

Build the attack, then build the defense.

GenAI is making payment fraud faster, cheaper, and harder to spot. In this red team/blue team challenge, you take on both sides of the problem by building one end-to-end Red Teaming AI system that:

Identifies novel emerging GenAI-powered payment fraud attacks,
Generates realistic simulations of those attacks at scale, and
Defends against them with an accurate detection model.
Goal: Build a closed-loop AI system that discovers emerging GenAI payment fraud, recreates it with high fidelity, and reliably detects it. The best solutions turn their own simulated attacks into the training ground for a stronger defense.

Start

18 days ago
Close

3 days to go
Description
Generative AI has lowered the barrier for sophisticated, fast-evolving payment fraud. Static, rule-based defenses struggle to keep pace with attacks that are novel, adaptive, and generated at scale. The Mastercard Innovation Challenge 2026, hosted at the Global Fintech Fest (GFF) 2026 (9–11 September, Jio World Centre, Mumbai), invites participants to fight fire with fire: use AI to stress-test and harden payment security.

This is a closed-loop, red-team/blue-team challenge. Rather than tackling detection in isolation, participants own the full cycle - first imagining how fraud could evolve, then building the tooling to reproduce it faithfully and finally engineering a model that catches it. The strongest submissions treat these three pillars as a single feedback loop: the attacks you generate become the training and stress-testing ground for the defense you build, and the gaps your defense reveals feed back into new attack ideas.

The Problem: Identify, Generate, Defend
Build an end-to-end Red Teaming AI system structured across three core pillars:

Identify (ideate) - Research and map the landscape of emerging, novel GenAI-powered fraud attacks targeting payments. Be thorough and exhaustive: the goal is breadth and depth. Surface as many distinct, plausible attack vectors as possible across channels, rails, and social-engineering surfaces rather than a narrow handful. Ground each idea in how real payment systems and fraud actually work.
Generate - Build algorithms and agents that generate and simulate those attacks at scale. Prioritise fidelity: the synthetic attacks and transactions should closely resemble real payment data and real fraud patterns - realistic distributions, behaviours and edge cases so they are genuinely useful for training and stress-testing a defense.
Defend - Build an AI/ML solution (for example, a classifier) that detects, flags, and mitigates the generated attacks. Prioritise accuracy: maximise detection performance (precision, recall, F1 / AUC) on the simulated attacks while keeping false positives on legitimate payments low.
What Your Solution Should Achieve
Your submission is an end-to-end technical solution, evaluated on:

Diversity of attacks identified
Fidelity of attacks in simulation
Detection algorithms and their efficacy
Novelty of the solution
Real-world feasibility in live payments
Who Should Participate
The challenge is open to:

Startups
Individuals (tech professionals, market researchers, and others)
Students (undergraduate, postgraduate, doctoral)
Financial Institutions, Fintechs & DeepTech teams
Teams can have 1-5 members.

Timeline
Date	Milestone
10th Aug.	Registration opens
20th Aug.	Registration closes
31st Aug.	Submission deadline
5th Sep.	Results announced
8th-11th Sep.	Top teams present at GFF 2026
Prizes & Recognition
1st Prize: ₹2,56,000 (~$2690)
2nd Prize: ₹1,28,000 (~$1345)
3rd Prize: ₹64,000 (~$672)
Winning teams also receive a showcase opportunity at GFF 2026, Mumbai.

Submission Requirements
A valid submission (write-up) must contain the following three artifacts, submitted from the "Writeups" section prior to the deadline. Any un-submitted or draft work by the deadline will not be considered by the judges.

1. Code Repository
A complete, runnable code repository (hosted on Github) covering all three pillars of the solution - identify, generate, and defend. Your code should be organized, documented and reproducible.

2. Solution Walkthrough
A word document (as .docx) that walks through your approach, including:

The novel fraud attacks you identified
How your system generates and simulates those attacks
Your detection and mitigation model, with efficacy results
Real-world feasibility in live payment environments
3. Working Prototype (Web)
A working web-based prototype with a presentable UI that demonstrates the closed-loop system in action.

Tracks and Awards
AI Defense Lab for Payment Security · $4,707
Generative AI is making payment fraud faster, cheaper, and harder to detect. In this red team / blue team challenge, you build one end-to-end Adversarial AI system that owns the full cycle:

Identify - Research and surface emerging, novel GenAI-powered fraud attacks targeting payments. Be thorough and exhaustive - breadth and depth of attack vectors.
Generate - Build agents that simulate those attacks at scale with high fidelity, closely resembling real payment data and fraud patterns.
Defend - Build an AI/ML solution (e.g., a classifier) that accurately detects, flags, and mitigates the generated attacks while keeping false positives low.
What you submit: a code repository, a solution walkthrough (deck/doc), and a working web prototype with a presentable UI.

Judged on: diversity of attacks identified · fidelity of simulated attacks · detection efficacy · novelty · real-world feasibility in live payments.


1st Prize
Winning Team (INR 2,56,000)

$2,690

2nd Prize
First runner-up (INR 1,28,000)

$1,345

3rd Prize
Second runner-up (INR 64,000)

$672
Evaluation
Submissions will be scored on:

Diversity of attacks identified
Fidelity of attacks in simulation
Detection algorithm efficacy
Novelty of the overall solution
Real-world feasibility in live payments